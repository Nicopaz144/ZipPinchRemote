# ZipPinchRemote — streaming experimental

This project experiments with sequential HTTP download and ZIP extraction without saving a complete ZIP archive to disk.

## Build
1. Extract the project ZIP.
2. Upload/replace the project files in your GitHub repository.
3. Run **Actions → Build unsigned iOS IPA → Run workflow**.
4. Check the full build log and download the IPA artifact only if the workflow succeeds.

## Current limitations
- The streaming parser currently rejects encrypted entries, ZIP64, data-descriptor entries, and compression methods other than Stored and DEFLATE.
- Some ZIP files put key metadata only in the central directory; this parser depends on local headers having known sizes and no data descriptor.
- HTTP servers may redirect or return errors; the app must have access to the direct download URL.
- This source-level fix has not been compiled with Xcode in this environment and has not been tested on a physical iPhone. Do not treat it as a verified working build until GitHub Actions succeeds and a small test ZIP is extracted correctly.
- Keep the original archive until the extracted files have been verified.
