# ZipPinchRemote — streaming experimental

Experimental iOS project for sequential HTTP download and ZIP extraction without saving the full ZIP archive to disk.

## Build
1. Extract this project ZIP.
2. Replace the files in your GitHub repository with these files.
3. Run **Actions → Build unsigned iOS IPA → Run workflow**.
4. Install the IPA only if the workflow succeeds.

## Important limitations
- Supports only local ZIP headers with known sizes and compression methods Stored (0) or DEFLATE (8).
- Does not yet support encrypted entries, ZIP64, or entries using data descriptors.
- A host can respond with an HTML page instead of the actual archive, even with HTTP 200. This version detects common HTML responses and displays a clearer error; it does not fix an expired/blocked/non-direct URL.
- Source has not been compiled with Xcode or verified on a physical iPhone in this environment.
- Test with a small ZIP first and keep the original archive until all extracted files are verified.
