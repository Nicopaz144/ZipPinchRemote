# ZipPinch Remote (iOS)

Small SwiftUI app wrapper around the MIT-licensed ZipPinch library. It lists files in a remote ZIP using HTTP range requests and downloads only a selected entry.

## Build IPA on GitHub Actions (Windows-friendly)

1. Create a new **public** GitHub repository named `ZipPinchRemote` (public repos generally have the simplest GitHub Actions access).
2. Upload the contents of this folder to the repository root (not the parent folder).
3. Open **Actions** in the repository and enable workflows if prompted.
4. Open the workflow **Build unsigned iOS IPA** and choose **Run workflow**.
5. When it finishes, open the run and download the artifact named `ZipPinchRemote-unsigned-IPA`.
6. Extract the artifact ZIP. It contains `ZipPinchRemote.ipa`.
7. Import `ZipPinchRemote.ipa` into SideStore. SideStore should sign it with your own device provisioning; if it reports an unsupported/invalid IPA, send the exact error.

## Important
- This workflow builds an **unsigned** IPA; it does not require sharing Apple credentials. SideStore is expected to sign it during installation.
- This project has not been compiled/tested in this environment. If the build fails, open the failed Actions run and share the first red error lines.
- The archive server must support HTTP `Range` requests for efficient partial access. A ZIP URL requiring login or a webpage URL rather than a direct `.zip` URL may not work.
- ZipPinch is MIT-licensed: https://github.com/buh/ZipPinch
