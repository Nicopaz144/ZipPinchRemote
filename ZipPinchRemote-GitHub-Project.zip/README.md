# ZipPinch Remote — build de diagnóstico HTTP Range

Proyecto SwiftUI para iPhone con navegador WebKit, descarga convencional de ZIP y una nueva prueba segura de compatibilidad HTTP Range.

## Cambios de esta versión
- La pantalla Navegar abre con el enlace GTAV.zip proporcionado para la prueba. Se puede reemplazar por cualquier otra URL.
- Se agregó **Comprobar soporte Range**. Envía `Range: bytes=0-0` y cancela la petición en cuanto recibe los encabezados. Si el servidor ignora Range, la prueba no espera a descargar el cuerpo completo.
- Muestra el código HTTP y si la respuesta incluye `Content-Range`, dato necesario para evaluar una posible extracción remota.
- La descarga y extracción local tradicionales siguen disponibles desde las descargas interceptadas por WebKit.

## Limitación importante: todavía no es extracción remota
Esta versión **no implementa todavía la extracción ZIP por rangos**. La prueba Range solo verifica una condición necesaria; un resultado positivo no significa que el ZIP se pueda extraer por partes. La extracción existente continúa descargando el ZIP completo antes de extraerlo y borrarlo después.

El siguiente desarrollo debe implementar lectura del directorio central ZIP, soporte de ZIP64 cuando corresponda, extracción por entrada con descompresión incremental y validación de rutas/CRC. No se debe usar un método que acumule archivos de varios GB en RAM. El servidor también puede redirigir o cambiar su política de acceso.

## Probar el enlace de GTAV.zip
1. Compilá e instalá la app desde el artefacto de GitHub Actions.
2. Abrí la pestaña **Navegar**. El campo ya contiene el enlace proporcionado; no hace falta tocar Ir para probarlo.
3. Tocá **Comprobar soporte Range**.
4. Esperá el mensaje. HTTP 206 con `Content-Range` significa que la respuesta acepta rangos para esa URL en ese momento. HTTP 200 indica que esa respuesta ignoró el rango. Errores/403/404 pueden indicar que el enlace expiró o necesita otra URL final.
5. Compartí el texto del resultado para definir el siguiente paso.

## Compilar IPA sin firma
1. Subí el contenido del proyecto a la raíz de un repositorio GitHub.
2. Abrí **Actions → Build unsigned iOS IPA → Run workflow**.
3. Descargá el artefacto `ZipPinchRemote-unsigned-IPA` si la compilación termina correctamente.
4. Instalá la IPA con tu método de sideloading habitual.

La IPA no está incluida en este ZIP. Este proyecto modificado no se ha compilado ni probado en un iPhone en este entorno. Si falla, compartí el primer error rojo completo de GitHub Actions.
