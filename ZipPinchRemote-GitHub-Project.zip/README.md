# ZipPinch Remote — extracción secuencial en streaming

Proyecto SwiftUI para iOS con navegador WebKit, descarga ZIP convencional y un modo experimental de extracción secuencial.

## Qué incorpora esta versión

- El campo de URL viene precargado con el enlace `GTAV.zip` que compartiste; podés cambiarlo.
- **Comprobar soporte Range** conserva la prueba anterior. Cancela la petición al recibir los encabezados y no espera el cuerpo cuando el servidor responde HTTP 200.
- **Extraer en streaming (sin guardar el ZIP)** pide una carpeta de destino y procesa el cuerpo de la respuesta en orden. No crea un archivo ZIP temporal completo: las entradas se escriben a medida que llegan los datos.
- Admite entradas ZIP con tamaños declarados en el encabezado local, sin cifrado, métodos Stored (0) y Deflate (8), y rutas relativas seguras.
- El enlace de GoFile puede redirigir o devolver una página de error; la app informará si la respuesta no es un ZIP válido.

## Limitaciones importantes del modo streaming experimental

Este motor es una primera implementación y **no está verificado todavía con tu GTAV.zip ni compilado en un iPhone**. Para evitar resultados corruptos, rechaza ZIP cifrados, ZIP64, métodos de compresión distintos de 0/8 y entradas que usan el bit de descriptor de datos (bit 3). Muchos ZIP normales funcionan con encabezados locales que declaran los tamaños, pero no todos. Aún no valida CRC ni compara de forma estricta el tamaño final de cada entrada; no uses esta versión como única copia de datos importantes.

No se guarda el ZIP entero, pero los archivos extraídos ocupan su tamaño normal en la carpeta elegida y se necesita espacio suficiente para ellos. Si el servidor entrega HTML, requiere autorización o corta la conexión, la operación falla y puede dejar archivos parciales; revisalos y borrá la carpeta parcial antes de reintentar.

## Compilar IPA sin firma

1. Subí el contenido del proyecto a la raíz de un repositorio GitHub.
2. Abrí **Actions → Build unsigned iOS IPA → Run workflow**.
3. Descargá `ZipPinchRemote-unsigned-IPA` si el workflow termina correctamente.
4. Instalá la IPA con tu método habitual de sideloading.

El ZIP del proyecto no incluye una IPA compilada. La compilación debe hacerse en macOS con Xcode; esta entrega no ha sido compilada ni probada en un iPhone. Si Actions falla, compartí el primer error rojo completo.
