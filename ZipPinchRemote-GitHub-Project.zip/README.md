# ZipPinch Remote (iOS)

La app está orientada a **descargar y extraer automáticamente** un ZIP remoto; no muestra una lista navegable del contenido del ZIP. Usa ZipPinch para leer entradas remotas por rangos HTTP cuando el servidor lo permite.

## Crear la IPA con GitHub Actions

1. Subí el contenido de este proyecto al repositorio, en la raíz.
2. Abrí **Actions** y ejecutá **Build unsigned iOS IPA**.
3. Descargá el artefacto `ZipPinchRemote-unsigned-IPA` y extraé `ZipPinchRemote.ipa`.
4. Instalá la IPA con SideStore.

## Uso

1. Abrí **Navegador integrado** y entrá a la página del archivo.
2. Tocá el botón de descarga del sitio. La app intenta detectar URLs de descarga que aparezcan en enlaces, navegación o respuestas fetch/XHR.
3. Cuando aparezca un enlace candidato, tocá **Descargar y descomprimir**.
4. La app extrae los archivos en una carpeta temporal y abre la hoja Compartir para guardarlos en Archivos.

## Límites importantes

- Este proyecto no se ha compilado ni probado en un iPhone desde este entorno.
- La captura de enlaces depende de cómo el sitio implemente sus descargas; algunas páginas usan mecanismos que una WebView no permite interceptar.
- Para evitar guardar el ZIP completo, el servidor debe permitir solicitudes HTTP Range y ZipPinch debe soportar el formato del archivo. La extracción sí ocupa el espacio del contenido descomprimido.
- Un enlace a una página HTML no es un enlace directo al ZIP.
