# ZipPinch Remote (iOS)

La app está orientada a **descargar y extraer automáticamente** un ZIP remoto; no muestra una lista navegable del contenido del ZIP. Usa ZipPinch para leer entradas remotas por rangos HTTP cuando el servidor lo permite.

## Crear la IPA con GitHub Actions

1. Subí el contenido de este proyecto al repositorio, en la raíz.
2. Abrí **Actions** y ejecutá **Build unsigned iOS IPA**.
3. Descargá el artefacto `ZipPinchRemote-unsigned-IPA` y extraé `ZipPinchRemote.ipa`.
4. Instalá la IPA con SideStore.

## Uso

1. Abrí **Navegador integrado** y entrá a la página del archivo.
2. Tocá el botón de descarga del sitio. La app inspecciona la respuesta final de navegación cuando WebKit la reconoce como archivo adjunto/ZIP.
3. Si detecta una respuesta de descarga, cancela la descarga normal del navegador e inicia automáticamente el lector remoto de ZipPinch con la URL final; no hace falta tocar un segundo botón.
4. La app intenta extraer los archivos en una carpeta temporal y abre la hoja Compartir para guardarlos en Archivos.

## Límites importantes

- Este proyecto no se ha compilado ni probado en un iPhone desde este entorno.
- La captura automática depende de que WebKit exponga la descarga como una respuesta de archivo adjunto/ZIP. Algunas descargas iniciadas mediante JavaScript, ventanas nuevas o APIs internas pueden no ser detectables por este método.
- Para evitar guardar el ZIP completo, el servidor debe permitir solicitudes HTTP Range y ZipPinch debe soportar el formato del archivo. La extracción sí ocupa el espacio del contenido descomprimido.
- Un enlace a una página HTML no es un enlace directo al ZIP.
