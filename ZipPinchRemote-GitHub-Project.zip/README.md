# ZipPinch Remote — proyecto reconstruido

Este proyecto se creó desde cero como una app SwiftUI para iPhone con navegador WebKit integrado, detección de respuestas de descarga, descarga temporal y extracción local de ZIP mediante ZIPFoundation.

## Funciones previstas
- Abrir GoFile u otra página desde el navegador integrado.
- Detectar navegaciones cuya respuesta parezca un archivo adjunto o ZIP y convertirlas en una descarga de WebKit.
- Guardar el ZIP temporalmente, extraerlo a una carpeta temporal y borrar el ZIP después de extraerlo.
- Mostrar la hoja Compartir de iOS para guardar/compartir la carpeta extraída.
- Compilar una IPA sin firma mediante GitHub Actions.

## Limitaciones importantes
- Este método **descarga el ZIP completo antes de extraerlo**; no hace extracción remota por rangos ni evita el espacio temporal del ZIP.
- La detección funciona cuando la descarga se produce como una navegación/respuesta que WebKit puede convertir en `WKDownload`. Si el sitio inicia la descarga mediante JavaScript/XHR/blob o exige un flujo especial, puede no interceptarse automáticamente.
- La IPA no está incluida: GitHub Actions debe compilarla en macOS. El proyecto no se ha compilado ni probado en un iPhone en este entorno.

## Compilar
1. Subí el contenido de este proyecto a la raíz de un repositorio GitHub.
2. Abrí **Actions → Build unsigned iOS IPA → Run workflow**.
3. Descargá el artefacto `ZipPinchRemote-unsigned-IPA` cuando el workflow termine correctamente.
4. Instalá la IPA con tu método de sideloading habitual.

Si falla, compartí el primer error rojo completo de GitHub Actions. No borres la app anterior del iPhone hasta comprobar la nueva.
