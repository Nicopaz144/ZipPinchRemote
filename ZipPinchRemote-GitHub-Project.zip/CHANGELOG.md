# Changelog

## Streaming experimental build fix
- Fixed the `extractionUpdated` call to pass the required `label:` argument.
- Configured the target's Objective-C bridging header so Swift can import the zlib C API used for raw DEFLATE streaming.
- This is a source-level build fix; the project still needs to be compiled in Xcode/GitHub Actions and tested against the actual ZIP.
