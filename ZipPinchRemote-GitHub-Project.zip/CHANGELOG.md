# Changelog

## Streaming diagnostic fix
- Detects common HTML responses before parsing them as ZIP data.
- Shows a useful message when a host returns an HTML landing/error page with HTTP 200.
- This is a diagnostic improvement; it does not turn a non-direct URL into a direct ZIP URL or add support for ZIP64/data descriptors.
