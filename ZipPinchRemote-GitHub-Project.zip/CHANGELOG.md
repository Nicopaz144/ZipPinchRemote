# Cambios

## Diagnóstico Range para GTAV.zip
- URL de prueba precargada en la interfaz.
- Comprobación HTTP Range que cancela la solicitud al recibir encabezados para evitar descargar accidentalmente el archivo completo si el servidor ignora Range.
- Mensajes en español para HTTP 206, HTTP 200 y errores de red.
- Se documenta explícitamente que la extracción remota por rangos todavía no está implementada.
