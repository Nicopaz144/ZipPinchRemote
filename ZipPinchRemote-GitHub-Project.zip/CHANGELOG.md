# Cambios — extracción secuencial

- Añadido `StreamingZipExtractor.swift`: parser secuencial de encabezados locales ZIP, descarga por URLSession y escritura incremental de entradas sin almacenar el ZIP completo.
- Añadido soporte DEFLATE incremental mediante zlib del sistema iOS.
- Añadido botón de extracción en streaming y selector de carpeta de destino.
- Añadida protección de rutas y rechazo explícito de formatos no soportados (ZIP64, cifrado, descriptor de datos y métodos distintos de Stored/Deflate).
- Se mantiene la descarga convencional existente como alternativa.
- Estado: implementación experimental, pendiente de compilación y prueba real con GTAV.zip. No se afirma compatibilidad con todos los ZIP.
