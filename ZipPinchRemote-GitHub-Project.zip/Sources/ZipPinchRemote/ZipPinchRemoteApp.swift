import SwiftUI

@main
struct ZipPinchRemoteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
