import Foundation

/// Safely checks whether a remote URL honors a one-byte HTTP Range request.
/// The task is cancelled as soon as response headers arrive, so a server that
/// ignores Range cannot make the app download the whole archive during the test.
struct RemoteRangeCheckResult {
    let supportsRanges: Bool
    let statusCode: Int?
    let contentRange: String?
    let finalURL: URL?
    let message: String
}

enum RemoteRangeChecker {
    static func check(_ url: URL) async -> RemoteRangeCheckResult {
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("bytes=0-0", forHTTPHeaderField: "Range")
        request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        request.timeoutInterval = 20
        return await withCheckedContinuation { continuation in
            let probe = Probe(continuation: continuation)
            probe.start(request)
        }
    }

    private final class Probe: NSObject, URLSessionDataDelegate {
        private let lock = NSLock()
        private var continuation: CheckedContinuation<RemoteRangeCheckResult, Never>?
        private var session: URLSession?
        private var finished = false

        init(continuation: CheckedContinuation<RemoteRangeCheckResult, Never>) {
            self.continuation = continuation
        }

        func start(_ request: URLRequest) {
            let config = URLSessionConfiguration.ephemeral
            config.timeoutIntervalForRequest = 20
            let created = URLSession(configuration: config, delegate: self, delegateQueue: nil)
            session = created
            created.dataTask(with: request).resume()
        }

        func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
                        didReceive response: URLResponse,
                        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
            let http = response as? HTTPURLResponse
            let code = http?.statusCode
            let range = http?.value(forHTTPHeaderField: "Content-Range")
            let supports = code == 206 && range != nil
            let message: String
            if supports {
                message = "El servidor acepta Range (HTTP 206). Esto es un requisito para la extracción remota, pero no garantiza compatibilidad completa con este ZIP."
            } else if code == 200 {
                message = "El servidor ignoró Range (HTTP 200). La app no descargó el cuerpo durante esta prueba; no se puede usar extracción remota por fragmentos con esta respuesta."
            } else {
                message = "No se pudo confirmar Range (HTTP \(code.map(String.init) ?? "sin respuesta")). Puede requerir una URL final o autorización distinta."
            }
            finish(RemoteRangeCheckResult(supportsRanges: supports, statusCode: code,
                                          contentRange: range, finalURL: response.url, message: message))
            completionHandler(.cancel) // Stop before receiving the response body.
        }

        func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
            guard error != nil else { return }
            finish(RemoteRangeCheckResult(supportsRanges: false, statusCode: nil,
                                          contentRange: nil, finalURL: task.response?.url,
                                          message: "No se pudo comprobar el servidor: \(error!.localizedDescription)"))
        }

        private func finish(_ result: RemoteRangeCheckResult) {
            lock.lock()
            guard !finished else { lock.unlock(); return }
            finished = true
            let continuation = self.continuation
            self.continuation = nil
            lock.unlock()
            continuation?.resume(returning: result)
            session?.invalidateAndCancel()
        }
    }
}
