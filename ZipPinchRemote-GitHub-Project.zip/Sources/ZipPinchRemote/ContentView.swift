import SwiftUI
import WebKit
import ZIPFoundation

struct ContentView: View {
    @State private var address = "https://gofile.io"
    @State private var status = "Abrí GoFile y tocá el botón de descarga del archivo ZIP."
    @State private var busy = false
    @State private var folderToShare: URL?
    @State private var showShare = false
    @State private var browserID = UUID()

    var body: some View {
        NavigationView {
            VStack(spacing: 10) {
                HStack(spacing: 8) {
                    TextField("URL de GoFile", text: $address)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                    Button("Ir") { navigate() }
                        .buttonStyle(.borderedProminent)
                }
                HStack {
                    if busy { ProgressView().scaleEffect(0.85) }
                    Text(status)
                        .font(.footnote)
                        .foregroundColor(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                }
                BrowserView(startURL: normalizedURL(address), status: $status, busy: $busy, onZIPReady: { zipURL in
                    extract(zipURL)
                })
                .id(browserID)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .padding(12)
            .navigationTitle("ZipPinch Remote")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Inicio") {
                        address = "https://gofile.io"
                        navigate()
                    }
                }
            }
            .sheet(isPresented: $showShare) {
                if let folderToShare { ShareSheet(items: [folderToShare]) }
            }
        }
    }

    private func navigate() {
        guard normalizedURL(address) != nil else {
            status = "La dirección no es válida. Incluí https://"
            return
        }
        browserID = UUID()
        status = "Abriendo página…"
    }

    private func normalizedURL(_ value: String) -> URL? {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return URL(string: trimmed.contains("://") ? trimmed : "https://" + trimmed)
    }

    private func extract(_ zipURL: URL) {
        busy = true
        status = "Descarga terminada. Extrayendo archivos…"
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let fm = FileManager.default
                let root = fm.temporaryDirectory.appendingPathComponent("ZipPinch-\(UUID().uuidString)", isDirectory: true)
                try fm.createDirectory(at: root, withIntermediateDirectories: true)
                let archive = try Archive(url: zipURL, accessMode: .read)
                for entry in archive {
                    let safeParts = entry.path.split(separator: "/").filter { $0 != ".." && $0 != "." }
                    guard !safeParts.isEmpty else { continue }
                    let destination = safeParts.reduce(root) { $0.appendingPathComponent(String($1)) }
                    if entry.type == .directory {
                        try fm.createDirectory(at: destination, withIntermediateDirectories: true)
                    } else {
                        try fm.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
                        _ = try archive.extract(entry, to: destination)
                    }
                }
                try? fm.removeItem(at: zipURL)
                DispatchQueue.main.async {
                    busy = false
                    status = "Extracción lista. Compartí la carpeta para guardarla en Archivos."
                    folderToShare = root
                    showShare = true
                }
            } catch {
                try? FileManager.default.removeItem(at: zipURL)
                DispatchQueue.main.async {
                    busy = false
                    status = "No se pudo extraer el ZIP: \(error.localizedDescription)"
                }
            }
        }
    }
}

private struct BrowserView: UIViewRepresentable {
    let startURL: URL?
    @Binding var status: String
    @Binding var busy: Bool
    let onZIPReady: (URL) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.uiDelegate = context.coordinator
        web.allowsBackForwardNavigationGestures = true
        if let startURL { web.load(URLRequest(url: startURL)) }
        return web
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
        var parent: BrowserView
        private var downloadedFileURL: URL?
        init(parent: BrowserView) { self.parent = parent }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async { self.parent.status = "Cargando página…" }
        }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async { self.parent.status = "Página lista. Tocá Descargar en GoFile." }
        }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async { self.parent.status = "Error al abrir la página: \(error.localizedDescription)" }
        }

        func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
            download.delegate = self
            DispatchQueue.main.async {
                self.parent.busy = true
                self.parent.status = "Descargando ZIP…"
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            let response = navigationResponse.response
            let mime = (response.mimeType ?? "").lowercased()
            let name = (response.suggestedFilename ?? "").lowercased()
            let disposition = ((response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition") ?? "").lowercased()
            let looksLikeArchive = name.hasSuffix(".zip") || mime.contains("zip") || mime.contains("x-zip") || disposition.contains("attachment")
            if navigationResponse.canShowMIMEType == false || looksLikeArchive {
                decisionHandler(.download)
            } else {
                decisionHandler(.allow)
            }
        }

        func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
            let filename = suggestedFilename.isEmpty ? "download.zip" : suggestedFilename
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent("ZipPinch-\(UUID().uuidString)-\(filename)")
            downloadedFileURL = destination
            completionHandler(destination)
        }

        func downloadDidFinish(_ download: WKDownload) {
            let latest = downloadedFileURL
            guard let latest, FileManager.default.fileExists(atPath: latest.path) else {
                DispatchQueue.main.async { self.parent.busy = false; self.parent.status = "La descarga terminó, pero no encontré un archivo .zip. Probá con un enlace directo al ZIP." }
                return
            }
            DispatchQueue.main.async {
                self.parent.status = "ZIP descargado. Preparando extracción…"
                self.parent.onZIPReady(latest)
            }
        }

        func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
            DispatchQueue.main.async {
                self.parent.busy = false
                self.parent.status = "Falló la descarga: \(error.localizedDescription)"
            }
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
                webView.load(URLRequest(url: url))
            }
            return nil
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
