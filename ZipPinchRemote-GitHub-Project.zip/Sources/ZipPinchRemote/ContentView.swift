import SwiftUI
import WebKit
import ZipPinch
import UniformTypeIdentifiers
import UIKit

struct ContentView: View {
    @State private var urlText = ""
    @State private var entries: [ZIPEntry] = []
    @State private var status = "Pegá un enlace directo a un archivo .zip o abrí el navegador."
    @State private var busy = false
    @State private var exportedURL: URL?
    @State private var showShare = false
    @State private var showBrowser = false
    @State private var browserStartURL = "https://gofile.io/"
    @State private var browserPageURL = "https://gofile.io/"
    @State private var browserDownloadURL = ""

    private let session = URLSession(configuration: .default)

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack {
                    TextField("https://servidor/archivo.zip", text: $urlText)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                    Button("Abrir ZIP") { Task { await loadZIP() } }
                        .buttonStyle(.borderedProminent)
                        .disabled(busy || !isHTTPURL(urlText))
                }

                Button {
                    browserStartURL = isHTTPURL(urlText) ? urlText : "https://gofile.io/"
                    browserPageURL = browserStartURL
                    browserDownloadURL = ""
                    showBrowser = true
                } label: {
                    Label("Navegador integrado", systemImage: "globe")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                HStack(alignment: .top) {
                    Text(status)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    if busy { ProgressView().controlSize(.small) }
                }

                Button("Diagnosticar enlace pegado") { Task { await diagnoseURL() } }
                    .buttonStyle(.borderless)
                    .font(.footnote)
                    .disabled(busy || !isHTTPURL(urlText))

                List(entries, id: \.id) { entry in
                    HStack(spacing: 10) {
                        Image(systemName: entry.isDirectory ? "folder" : "doc")
                            .foregroundStyle(entry.isDirectory ? .orange : .blue)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(entry.filePath)
                                .font(.subheadline)
                                .lineLimit(3)
                            if !entry.isDirectory {
                                Text(ByteCountFormatter.string(fromByteCount: entry.uncompressedSize, countStyle: .file))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        if !entry.isDirectory {
                            Button {
                                Task { await download(entry) }
                            } label: {
                                Image(systemName: "arrow.down.circle")
                                    .font(.title3)
                            }
                            .buttonStyle(.plain)
                            .disabled(busy)
                        }
                    }
                    .padding(.vertical, 3)
                }
                .listStyle(.plain)
            }
            .padding()
            .navigationTitle("ZipPinch Remote")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Limpiar") {
                        entries = []
                        status = "Pegá un enlace directo a un archivo .zip o abrí el navegador."
                        exportedURL = nil
                    }
                }
            }
            .sheet(isPresented: $showBrowser) {
                NavigationStack {
                    VStack(spacing: 8) {
                        BrowserView(
                            startURL: browserStartURL,
                            onPageURL: { browserPageURL = $0 },
                            onDownloadCandidate: { candidate in
                                browserDownloadURL = candidate
                            }
                        )
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Página actual")
                                .font(.caption.bold())
                            Text(browserPageURL)
                                .font(.caption2)
                                .lineLimit(2)
                                .textSelection(.enabled)
                            if !browserDownloadURL.isEmpty {
                                Text("Posible enlace de descarga detectado")
                                    .font(.caption.bold())
                                Text(browserDownloadURL)
                                    .font(.caption2)
                                    .lineLimit(2)
                                    .textSelection(.enabled)
                                Button {
                                    urlText = browserDownloadURL
                                    showBrowser = false
                                    status = "Enlace capturado. Tocá Abrir ZIP para intentar leer el índice."
                                } label: {
                                    Label("Usar enlace detectado", systemImage: "link")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            Button {
                                urlText = browserPageURL
                                showBrowser = false
                                status = "URL de la página copiada al campo. Si no es un enlace directo, el ZIP no podrá abrirse."
                            } label: {
                                Label("Usar URL de esta página", systemImage: "arrow.down.to.line")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered)
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 8)
                    }
                    .navigationTitle("Navegador")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarLeading) {
                            Button("Cerrar") { showBrowser = false }
                        }
                    }
                }
            }
            .sheet(isPresented: $showShare) {
                if let exportedURL {
                    ShareSheet(items: [exportedURL])
                }
            }
        }
    }

    private func isHTTPURL(_ value: String) -> Bool {
        guard let url = URL(string: value), let scheme = url.scheme?.lowercased() else { return false }
        return scheme == "https" || scheme == "http"
    }

    @MainActor
    private func diagnoseURL() async {
        guard isHTTPURL(urlText), let url = URL(string: urlText) else {
            status = "Pegá una URL http:// o https:// válida."
            return
        }
        busy = true
        status = "Consultando encabezados del servidor…"
        defer { busy = false }
        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        request.timeoutInterval = 20
        do {
            let (_, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                status = "Diagnóstico: respuesta no HTTP."
                return
            }
            let type = http.value(forHTTPHeaderField: "Content-Type") ?? "no indicado"
            let ranges = http.value(forHTTPHeaderField: "Accept-Ranges") ?? "no indicado"
            let length = http.value(forHTTPHeaderField: "Content-Length") ?? "no indicado"
            let finalURL = http.url?.absoluteString ?? "desconocida"
            status = "HTTP \(http.statusCode) · Tipo: \(type) · Rangos: \(ranges) · Tamaño: \(length) · URL final: \(finalURL)"
        } catch {
            status = "Falló diagnóstico HTTP: \(error.localizedDescription)"
        }
    }

    @MainActor
    private func loadZIP() async {
        guard isHTTPURL(urlText), let url = URL(string: urlText) else {
            status = "La URL debe empezar por http:// o https://."
            return
        }
        busy = true
        status = "Leyendo el índice remoto del ZIP…"
        defer { busy = false }
        do {
            let found = try await session.zipEntries(from: url)
            entries = found.sorted { $0.filePath.localizedCaseInsensitiveCompare($1.filePath) == .orderedAscending }
            status = "Encontrados \(entries.count) elementos. Tocá la flecha para bajar uno."
        } catch {
            status = "Error al leer ZIP: \(error.localizedDescription). Verificá que sea un enlace directo y que el servidor permita lecturas parciales."
        }
    }

    @MainActor
    private func download(_ entry: ZIPEntry) async {
        guard let url = URL(string: urlText) else { return }
        busy = true
        status = "Descargando \(entry.fileName)…"
        defer { busy = false }
        do {
            let data = try await session.zipEntryData(entry, from: url)
            let safeName = entry.fileName.isEmpty ? "archivo" : URL(fileURLWithPath: entry.fileName).lastPathComponent
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
            try data.write(to: destination, options: .atomic)
            exportedURL = destination
            status = "Listo: \(safeName). Usá Compartir → Guardar en Archivos."
            showShare = true
        } catch {
            status = "Error al descargar: \(error.localizedDescription)"
        }
    }
}

private struct BrowserView: UIViewRepresentable {
    let startURL: String
    let onPageURL: (String) -> Void
    let onDownloadCandidate: (String) -> Void

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        if let url = URL(string: startURL) {
            webView.load(URLRequest(url: url))
        }
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        if webView.url == nil, let url = URL(string: startURL) {
            webView.load(URLRequest(url: url))
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(onPageURL: onPageURL, onDownloadCandidate: onDownloadCandidate)
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let onPageURL: (String) -> Void
        let onDownloadCandidate: (String) -> Void

        init(onPageURL: @escaping (String) -> Void, onDownloadCandidate: @escaping (String) -> Void) {
            self.onPageURL = onPageURL
            self.onDownloadCandidate = onDownloadCandidate
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            guard let current = webView.url?.absoluteString else { return }
            DispatchQueue.main.async { self.onPageURL(current) }
            let script = "Array.from(document.querySelectorAll('a[href]')).map(a => a.href).filter(h => /\\.zip(?:$|[?#])|\\/download\\//i.test(h))"
            webView.evaluateJavaScript(script) { result, _ in
                guard let links = result as? [String], let candidate = links.first else { return }
                DispatchQueue.main.async { self.onDownloadCandidate(candidate) }
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = navigationAction.request.url {
                let value = url.absoluteString
                DispatchQueue.main.async {
                    self.onPageURL(value)
                    if value.localizedCaseInsensitiveContains(".zip") || value.localizedCaseInsensitiveContains("/download/") {
                        self.onDownloadCandidate(value)
                    }
                }
            }
            decisionHandler(.allow)
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
