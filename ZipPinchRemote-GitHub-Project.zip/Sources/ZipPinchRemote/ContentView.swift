import SwiftUI
import WebKit
import ZIPFoundation
import UniformTypeIdentifiers

struct ContentView: View {
    @State private var address = "https://gofile.io"
    @State private var status = "Abrí GoFile y tocá el botón de descarga del archivo ZIP."
    @State private var busy = false
    @State private var progress: Double? = nil
    @State private var browserID = UUID()
    @State private var pendingZIP: URL?
    @State private var showFolderPicker = false

    var body: some View {
        NavigationView {
            VStack(spacing: 10) {
                HStack(spacing: 8) {
                    TextField("URL de GoFile", text: $address)
                        .textInputAutocapitalization(.never)
                        .keyboardType(.URL)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                    Button("Ir") { navigate() }
                        .buttonStyle(.borderedProminent)
                }
                VStack(alignment: .leading, spacing: 6) {
                    HStack(spacing: 8) {
                        if busy {
                            if let progress {
                                ProgressView(value: progress)
                                    .frame(width: 90)
                                Text("\(Int(progress * 100))%")
                                    .font(.caption.monospacedDigit())
                            } else {
                                ProgressView()
                                Text("Descargando…")
                                    .font(.caption)
                            }
                        }
                        Text(status)
                            .font(.footnote)
                            .foregroundColor(.secondary)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                BrowserView(startURL: normalizedURL(address), status: $status, busy: $busy, onZIPReady: { zipURL in
                    pendingZIP = zipURL
                    busy = false
                    progress = nil
                    status = "ZIP descargado. Elegí la carpeta donde querés guardar los archivos extraídos."
                    showFolderPicker = true
                })
                .id(browserID)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            .padding(12)
            .navigationTitle("ZipPinch Remote")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Inicio") {
                        address = "https://gofile.io"
                        navigate()
                    }
                }
            }
            .fileImporter(isPresented: $showFolderPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
                switch result {
                case .success(let urls):
                    guard let folder = urls.first, let zip = pendingZIP else {
                        status = "No se eligió una carpeta. El ZIP temporal sigue pendiente."
                        return
                    }
                    extract(zip, into: folder)
                case .failure(let error):
                    status = "No se eligió carpeta: \(error.localizedDescription)"
                    if let pendingZIP { try? FileManager.default.removeItem(at: pendingZIP) }
                    pendingZIP = nil
                }
            }
        }
    }

    private func navigate() {
        guard normalizedURL(address) != nil else {
            status = "La dirección no es válida. Incluí https://"
            return
        }
        browserID = UUID()
        status = "Abriendo página…"
    }

    private func normalizedURL(_ value: String) -> URL? {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return URL(string: trimmed.contains("://") ? trimmed : "https://" + trimmed)
    }

    private func extract(_ zipURL: URL, into selectedFolder: URL) {
        busy = true
        progress = 0
        status = "Preparando carpeta de extracción…"
        DispatchQueue.global(qos: .userInitiated).async {
            let hasAccess = selectedFolder.startAccessingSecurityScopedResource()
            defer { if hasAccess { selectedFolder.stopAccessingSecurityScopedResource() } }
            do {
                let fm = FileManager.default
                let outputName = "ZipPinch-Extraído-\(Date.now.formatted(.dateTime.year().month().day().hour().minute()))"
                let root = selectedFolder.appendingPathComponent(outputName, isDirectory: true)
                try fm.createDirectory(at: root, withIntermediateDirectories: true)
                let archive = try Archive(url: zipURL, accessMode: .read)
                let entries = Array(archive)
                let total = max(entries.count, 1)
                for (index, entry) in entries.enumerated() {
                    let safeParts = entry.path.split(separator: "/").filter { $0 != ".." && $0 != "." }
                    guard !safeParts.isEmpty else { continue }
                    let destination = safeParts.reduce(root) { $0.appendingPathComponent(String($1)) }
                    if entry.type == .directory {
                        try fm.createDirectory(at: destination, withIntermediateDirectories: true)
                    } else {
                        try fm.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
                        try archive.extract(entry, to: destination)
                    }
                    let fraction = Double(index + 1) / Double(total)
                    DispatchQueue.main.async {
                        progress = fraction
                        status = "Extrayendo archivos… \(index + 1) de \(total)"
                    }
                }
                try? fm.removeItem(at: zipURL)
                DispatchQueue.main.async {
                    busy = false
                    progress = 1
                    status = "Listo. Archivos guardados en la carpeta elegida: \(outputName)"
                    pendingZIP = nil
                }
            } catch {
                DispatchQueue.main.async {
                    busy = false
                    progress = nil
                    status = "No se pudo extraer el ZIP: \(error.localizedDescription)"
                }
            }
        }
    }
}

private struct BrowserView: UIViewRepresentable {
    let startURL: URL?
    @Binding var status: String
    @Binding var busy: Bool
    let onZIPReady: (URL) -> Void

    func makeCoordinator() -> Coordinator { Coordinator(parent: self) }

    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences.allowsContentJavaScript = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator
        web.uiDelegate = context.coordinator
        web.allowsBackForwardNavigationGestures = true
        if let startURL { web.load(URLRequest(url: startURL)) }
        return web
    }

    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate, WKDownloadDelegate {
        var parent: BrowserView
        private var downloadedFileURL: URL?
        init(parent: BrowserView) { self.parent = parent }

        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) {
            DispatchQueue.main.async { self.parent.status = "Cargando página…" }
        }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            DispatchQueue.main.async { self.parent.status = "Página lista. Tocá Descargar en GoFile." }
        }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) {
            DispatchQueue.main.async { self.parent.status = "Error al abrir la página: \(error.localizedDescription)" }
        }

        func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) {
            download.delegate = self
            DispatchQueue.main.async {
                self.parent.busy = true
                self.parent.status = "Descargando ZIP… WebKit no informa porcentaje exacto de esta descarga."
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            let response = navigationResponse.response
            let mime = (response.mimeType ?? "").lowercased()
            let name = (response.suggestedFilename ?? "download").lowercased()
            let disposition = ((response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition") ?? "").lowercased()
            let looksLikeArchive = name.hasSuffix(".zip") || mime.contains("zip") || mime.contains("x-zip") || disposition.contains("attachment")
            if navigationResponse.canShowMIMEType == false || looksLikeArchive {
                decisionHandler(.download)
            } else {
                decisionHandler(.allow)
            }
        }

        func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
            let filename = suggestedFilename.isEmpty ? "download.zip" : suggestedFilename
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent("ZipPinch-\(UUID().uuidString)-\(filename)")
            downloadedFileURL = destination
            completionHandler(destination)
        }

        func downloadDidFinish(_ download: WKDownload) {
            let latest = downloadedFileURL
            guard let latest, FileManager.default.fileExists(atPath: latest.path) else {
                DispatchQueue.main.async { self.parent.busy = false; self.parent.status = "La descarga terminó, pero no encontré el ZIP. Probá con un enlace directo al archivo." }
                return
            }
            DispatchQueue.main.async {
                self.parent.status = "ZIP descargado. Elegí dónde extraerlo…"
                self.parent.onZIPReady(latest)
            }
        }

        func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
            DispatchQueue.main.async {
                self.parent.busy = false
                self.parent.status = "Falló la descarga: \(error.localizedDescription)"
            }
        }

        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url {
                webView.load(URLRequest(url: url))
            }
            return nil
        }
    }
}
