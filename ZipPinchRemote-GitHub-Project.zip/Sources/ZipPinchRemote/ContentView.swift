import SwiftUI
import ZipPinch
import UniformTypeIdentifiers
import UIKit

struct ContentView: View {
    @State private var urlText = ""
    @State private var entries: [ZIPEntry] = []
    @State private var selectedIDs: Set<String> = []
    @State private var status = "Pegá un enlace directo a un archivo .zip."
    @State private var busy = false
    @State private var exportedURL: URL?
    @State private var showShare = false

    private let session = URLSession(configuration: .default)

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack {
                    TextField("https://servidor/archivo.zip", text: $urlText)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                    Button("Abrir") { Task { await loadZIP() } }
                        .buttonStyle(.borderedProminent)
                        .disabled(busy || URL(string: urlText)?.scheme == nil)
                }
                HStack {
                    Text(status)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                    Spacer()
                    if busy { ProgressView().controlSize(.small) }
                }
                Button("Diagnosticar enlace") { Task { await diagnoseURL() } }
                    .buttonStyle(.bordered)
                    .disabled(busy || URL(string: urlText)?.scheme == nil)
                List(entries, id: \.id) { entry in
                    HStack(spacing: 10) {
                        Image(systemName: entry.isDirectory ? "folder" : "doc")
                            .foregroundStyle(entry.isDirectory ? .orange : .blue)
                        VStack(alignment: .leading, spacing: 3) {
                            Text(entry.filePath)
                                .font(.subheadline)
                                .lineLimit(3)
                            if !entry.isDirectory {
                                Text(ByteCountFormatter.string(fromByteCount: entry.uncompressedSize, countStyle: .file))
                                    .font(.caption)
                                    .foregroundStyle(.secondary)
                            }
                        }
                        Spacer()
                        if !entry.isDirectory {
                            Button {
                                Task { await download(entry) }
                            } label: {
                                Image(systemName: "arrow.down.circle")
                                    .font(.title3)
                            }
                            .buttonStyle(.plain)
                            .disabled(busy)
                        }
                    }
                    .padding(.vertical, 3)
                }
                .listStyle(.plain)
            }
            .padding()
            .navigationTitle("ZipPinch Remote")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Limpiar") {
                        entries = []
                        status = "Pegá un enlace directo a un archivo .zip."
                        exportedURL = nil
                    }
                }
            }
            .sheet(isPresented: $showShare) {
                if let exportedURL {
                    ShareSheet(items: [exportedURL])
                }
            }
        }
    }

    @MainActor
    private func diagnoseURL() async {
        guard let url = URL(string: urlText), url.scheme == "https" || url.scheme == "http" else {
            status = "Pegá una URL http:// o https:// válida."
            return
        }
        busy = true
        status = "Consultando encabezados del servidor…"
        defer { busy = false }
        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        request.timeoutInterval = 20
        do {
            let (_, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                status = "Diagnóstico: respuesta no HTTP."
                return
            }
            let type = http.value(forHTTPHeaderField: "Content-Type") ?? "no indicado"
            let ranges = http.value(forHTTPHeaderField: "Accept-Ranges") ?? "no indicado"
            let length = http.value(forHTTPHeaderField: "Content-Length") ?? "no indicado"
            let finalURL = http.url?.absoluteString ?? "desconocida"
            status = "HTTP \(http.statusCode) · Tipo: \(type) · Rangos: \(ranges) · Tamaño: \(length) · URL final: \(finalURL)"
        } catch {
            status = "Falló diagnóstico HTTP: \(error.localizedDescription)"
        }
    }

    @MainActor
    private func loadZIP() async {
        guard let url = URL(string: urlText), url.scheme == "https" || url.scheme == "http" else {
            status = "La URL debe empezar por http:// o https://."
            return
        }
        busy = true
        status = "Leyendo el índice remoto del ZIP…"
        defer { busy = false }
        do {
            let found = try await session.zipEntries(from: url)
            entries = found.sorted { $0.filePath.localizedCaseInsensitiveCompare($1.filePath) == .orderedAscending }
            status = "Encontrados \(entries.count) elementos. Tocá la flecha para bajar uno."
        } catch {
            status = "Error al leer ZIP: \(error.localizedDescription)"
        }
    }

    @MainActor
    private func download(_ entry: ZIPEntry) async {
        guard let url = URL(string: urlText) else { return }
        busy = true
        status = "Descargando \(entry.fileName)…"
        defer { busy = false }
        do {
            let data = try await session.zipEntryData(entry, from: url)
            let safeName = entry.fileName.isEmpty ? "archivo" : entry.fileName
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent(safeName)
            try data.write(to: destination, options: .atomic)
            exportedURL = destination
            status = "Listo: \(safeName). Usá Compartir → Guardar en Archivos."
            showShare = true
        } catch {
            status = "Error al descargar: \(error.localizedDescription)"
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
