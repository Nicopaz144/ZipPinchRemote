import SwiftUI
import WebKit
import ZipPinch
import UniformTypeIdentifiers
import UIKit

struct ContentView: View {
    @State private var urlText = ""
    @State private var entries: [ZIPEntry] = []
    @State private var status = "Abrí el navegador, entrá al archivo ZIP y usá Descargar y descomprimir."
    @State private var busy = false
    @State private var exportedURL: URL?
    @State private var showShare = false
    @State private var showBrowser = false
    @State private var browserStartURL = "https://gofile.io/"
    @State private var browserPageURL = "https://gofile.io/"
    @State private var browserDownloadURL = ""

    private let session = URLSession(configuration: .default)

    var body: some View {
        NavigationStack {
            VStack(spacing: 12) {
                HStack {
                    TextField("https://servidor/archivo.zip", text: $urlText)
                        .keyboardType(.URL)
                        .textInputAutocapitalization(.never)
                        .autocorrectionDisabled()
                        .textFieldStyle(.roundedBorder)
                    Button("Descargar y descomprimir") { Task { await extractZIP(from: urlText) } }
                        .buttonStyle(.borderedProminent)
                        .disabled(busy || !isHTTPURL(urlText))
                }

                Button {
                    browserStartURL = isHTTPURL(urlText) ? urlText : "https://gofile.io/"
                    browserPageURL = browserStartURL
                    browserDownloadURL = ""
                    showBrowser = true
                } label: {
                    Label("Navegador integrado", systemImage: "globe")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.bordered)

                HStack(alignment: .top) {
                    Text(status)
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .frame(maxWidth: .infinity, alignment: .leading)
                    if busy { ProgressView().controlSize(.small) }
                }

                Button("Diagnosticar enlace pegado") { Task { await diagnoseURL() } }
                    .buttonStyle(.borderless)
                    .font(.footnote)
                    .disabled(busy || !isHTTPURL(urlText))

                VStack(spacing: 10) {
                    Image(systemName: "archivebox")
                        .font(.system(size: 42))
                        .foregroundStyle(.secondary)
                    Text("Descarga y extracción automática")
                        .font(.headline)
                    Text("La app intentará leer el índice remoto y guardar los archivos extraídos sin conservar el ZIP completo. El servidor debe permitir lecturas parciales.")
                        .font(.footnote)
                        .foregroundStyle(.secondary)
                        .multilineTextAlignment(.center)
                    if !entries.isEmpty {
                        Text("Último ZIP: \(entries.count) elementos detectados")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .padding()
            .navigationTitle("ZipPinch Remote")
            .toolbar {
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Limpiar") {
                        entries = []
                        status = "Abrí el navegador, entrá al archivo ZIP y usá Descargar y descomprimir."
                        exportedURL = nil
                    }
                }
            }
            .sheet(isPresented: $showBrowser) {
                NavigationStack {
                    VStack(spacing: 8) {
                        BrowserView(
                            startURL: browserStartURL,
                            onPageURL: { browserPageURL = $0 },
                            onDownloadCandidate: { candidate in
                                browserDownloadURL = candidate
                            }
                        )
                        VStack(alignment: .leading, spacing: 8) {
                            Text("Página actual")
                                .font(.caption.bold())
                            Text(browserPageURL)
                                .font(.caption2)
                                .lineLimit(2)
                                .textSelection(.enabled)
                            if !browserDownloadURL.isEmpty {
                                Text("Posible enlace de descarga detectado")
                                    .font(.caption.bold())
                                Text(browserDownloadURL)
                                    .font(.caption2)
                                    .lineLimit(2)
                                    .textSelection(.enabled)
                                Button {
                                    urlText = browserDownloadURL
                                    showBrowser = false
                                    status = "Enlace capturado. Intentando descargar y descomprimir…"
                                    Task { await extractZIP(from: browserDownloadURL) }
                                } label: {
                                    Label("Descargar y descomprimir", systemImage: "arrow.down.to.line.compact")
                                        .frame(maxWidth: .infinity)
                                }
                                .buttonStyle(.borderedProminent)
                            }
                            Button {
                                urlText = browserPageURL
                                showBrowser = false
                                status = "URL copiada. Si es una página de alojamiento y no un enlace directo, abrí la descarga desde el navegador para capturarla."
                            } label: {
                                Label("Usar URL de esta página", systemImage: "arrow.down.to.line")
                                    .frame(maxWidth: .infinity)
                            }
                            .buttonStyle(.bordered)
                        }
                        .padding(.horizontal)
                        .padding(.bottom, 8)
                    }
                    .navigationTitle("Navegador")
                    .navigationBarTitleDisplayMode(.inline)
                    .toolbar {
                        ToolbarItem(placement: .topBarLeading) {
                            Button("Cerrar") { showBrowser = false }
                        }
                    }
                }
            }
            .sheet(isPresented: $showShare) {
                if let exportedURL {
                    ShareSheet(items: [exportedURL])
                }
            }
        }
    }

    private func isHTTPURL(_ value: String) -> Bool {
        guard let url = URL(string: value), let scheme = url.scheme?.lowercased() else { return false }
        return scheme == "https" || scheme == "http"
    }

    @MainActor
    private func diagnoseURL() async {
        guard isHTTPURL(urlText), let url = URL(string: urlText) else {
            status = "Pegá una URL http:// o https:// válida."
            return
        }
        busy = true
        status = "Consultando encabezados del servidor…"
        defer { busy = false }
        var request = URLRequest(url: url)
        request.httpMethod = "HEAD"
        request.timeoutInterval = 20
        do {
            let (_, response) = try await session.data(for: request)
            guard let http = response as? HTTPURLResponse else {
                status = "Diagnóstico: respuesta no HTTP."
                return
            }
            let type = http.value(forHTTPHeaderField: "Content-Type") ?? "no indicado"
            let ranges = http.value(forHTTPHeaderField: "Accept-Ranges") ?? "no indicado"
            let length = http.value(forHTTPHeaderField: "Content-Length") ?? "no indicado"
            let finalURL = http.url?.absoluteString ?? "desconocida"
            status = "HTTP \(http.statusCode) · Tipo: \(type) · Rangos: \(ranges) · Tamaño: \(length) · URL final: \(finalURL)"
        } catch {
            status = "Falló diagnóstico HTTP: \(error.localizedDescription)"
        }
    }

    @MainActor
    private func extractZIP(from rawURL: String) async {
        guard isHTTPURL(rawURL), let url = URL(string: rawURL) else {
            status = "La URL debe ser http:// o https:// válida. Abrí el navegador y capturá un enlace de descarga directa."
            return
        }
        busy = true
        entries = []
        status = "Leyendo el índice remoto del ZIP…"
        defer { busy = false }
        do {
            let found = try await session.zipEntries(from: url)
            entries = found
            let root = FileManager.default.temporaryDirectory
                .appendingPathComponent("ZipPinch-Extraido-\(UUID().uuidString)", isDirectory: true)
            try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
            let files = found.filter { !$0.isDirectory }
            guard !files.isEmpty else {
                status = "El ZIP no contiene archivos para extraer."
                return
            }
            var completed = 0
            for entry in files {
                let relative = safeRelativePath(entry.filePath)
                guard !relative.isEmpty else { continue }
                let destination = root.appendingPathComponent(relative)
                try FileManager.default.createDirectory(
                    at: destination.deletingLastPathComponent(),
                    withIntermediateDirectories: true
                )
                status = "Extrayendo \(completed + 1) de \(files.count): \(relative)"
                let data = try await session.zipEntryData(entry, from: url)
                try data.write(to: destination, options: .atomic)
                completed += 1
            }
            exportedURL = root
            status = "Extracción terminada: \(completed) archivos. Tocá Compartir para guardarlos en Archivos."
            showShare = true
        } catch {
            status = "No se pudo extraer: \(error.localizedDescription). El enlace debe apuntar al ZIP real y el servidor debe permitir lecturas parciales."
        }
    }

    private func safeRelativePath(_ path: String) -> String {
        let normalized = path.replacingOccurrences(of: "\\", with: "/")
        let parts = normalized.split(separator: "/").filter { !$0.isEmpty && $0 != "." && $0 != ".." }
        return parts.joined(separator: "/")
    }
}

private struct BrowserView: UIViewRepresentable {
    let startURL: String
    let onPageURL: (String) -> Void
    let onDownloadCandidate: (String) -> Void

    func makeUIView(context: Context) -> WKWebView {
        let configuration = WKWebViewConfiguration()
        let webView = WKWebView(frame: .zero, configuration: configuration)
        webView.navigationDelegate = context.coordinator
        webView.allowsBackForwardNavigationGestures = true
        if let url = URL(string: startURL) {
            webView.load(URLRequest(url: url))
        }
        return webView
    }

    func updateUIView(_ webView: WKWebView, context: Context) {
        if webView.url == nil, let url = URL(string: startURL) {
            webView.load(URLRequest(url: url))
        }
    }

    func makeCoordinator() -> Coordinator {
        Coordinator(onPageURL: onPageURL, onDownloadCandidate: onDownloadCandidate)
    }

    final class Coordinator: NSObject, WKNavigationDelegate {
        let onPageURL: (String) -> Void
        let onDownloadCandidate: (String) -> Void

        init(onPageURL: @escaping (String) -> Void, onDownloadCandidate: @escaping (String) -> Void) {
            self.onPageURL = onPageURL
            self.onDownloadCandidate = onDownloadCandidate
        }

        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            guard let current = webView.url?.absoluteString else { return }
            DispatchQueue.main.async { self.onPageURL(current) }
            let script = "Array.from(document.querySelectorAll('a[href]')).map(a => a.href).filter(h => /\\.zip(?:$|[?#])|\\/download\\//i.test(h))"
            webView.evaluateJavaScript(script) { result, _ in
                guard let links = result as? [String], let candidate = links.first else { return }
                DispatchQueue.main.async { self.onDownloadCandidate(candidate) }
            }
        }

        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            if let url = navigationAction.request.url {
                let value = url.absoluteString
                DispatchQueue.main.async {
                    self.onPageURL(value)
                    if value.localizedCaseInsensitiveContains(".zip") || value.localizedCaseInsensitiveContains("/download/") {
                        self.onDownloadCandidate(value)
                    }
                }
            }
            decisionHandler(.allow)
        }
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController {
        UIActivityViewController(activityItems: items, applicationActivities: nil)
    }
    func updateUIViewController(_ controller: UIActivityViewController, context: Context) {}
}
