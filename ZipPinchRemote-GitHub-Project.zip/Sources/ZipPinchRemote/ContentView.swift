import SwiftUI
import WebKit
import ZIPFoundation
import UniformTypeIdentifiers

@MainActor
final class DownloadManager: NSObject, ObservableObject, WKDownloadDelegate {
    @Published var status = "Abrí GoFile y tocá el botón de descarga del ZIP."
    @Published var isDownloading = false
    @Published var isPaused = false
    @Published var progress: Double?
    @Published var speedText = "—"
    @Published var etaText = "Calculando…"
    @Published var downloadedText = "0 MB"
    @Published var totalText = "Tamaño desconocido"
    @Published var currentFilename = "Ninguna descarga"
    @Published var isExtracting = false
    @Published var extractionProgress: Double = 0
    @Published var history: [DownloadRecord] = []

    weak var webView: WKWebView?
    private var activeDownload: WKDownload?
    private var resumeData: Data?
    private var timer: Timer?
    private var lastBytes: Int64 = 0
    private var lastSample = Date()
    private var currentBytesPerSecond: Double = 0
    var onZIPReady: ((URL) -> Void)?

    func attach(webView: WKWebView) { self.webView = webView }

    func begin(_ download: WKDownload, webView: WKWebView) {
        self.webView = webView
        activeDownload = download
        download.delegate = self
        isDownloading = true
        isPaused = false
        progress = 0
        speedText = "Calculando…"
        etaText = "Calculando…"
        downloadedText = "0 MB"
        totalText = "Esperando tamaño del servidor…"
        currentFilename = "Descarga ZIP"
        status = "Conectando y descargando…"
        startTimer(for: download)
        upsertHistory(state: "Descargando", fraction: 0)
    }

    func pause() {
        guard let download = activeDownload, isDownloading, !isPaused else { return }
        status = "Pausando descarga…"
        download.cancel { [weak self] data in
            DispatchQueue.main.async {
                guard let self else { return }
                self.timer?.invalidate(); self.timer = nil
                self.resumeData = data
                self.activeDownload = nil
                self.isDownloading = false
                self.isPaused = true
                self.speedText = "0 MB/s"
                self.etaText = "En pausa"
                self.status = data == nil
                    ? "Se pausó, pero WebKit no entregó datos para reanudar."
                    : "Descarga pausada. Podés reanudarla desde esta pantalla."
                self.upsertHistory(state: "En pausa", fraction: self.progress ?? 0)
            }
        }
    }

    func resume() {
        guard let data = resumeData, let webView else {
            status = "No hay datos de reanudación disponibles. Volvé a iniciar la descarga desde GoFile."
            return
        }
        status = "Reanudando descarga…"
        webView.resumeDownload(from: data) { [weak self] download in
            guard let self else { return }
            self.resumeData = nil
            self.begin(download, webView: webView)
            self.status = "Descarga reanudada."
        }
    }

    private func startTimer(for download: WKDownload) {
        timer?.invalidate()
        lastBytes = download.progress.completedUnitCount
        lastSample = Date()
        timer = Timer.scheduledTimer(withTimeInterval: 0.5, repeats: true) { [weak self, weak download] _ in
            guard let self, let download else { return }
            Task { @MainActor in self.updateProgress(download.progress) }
        }
    }

    private func updateProgress(_ p: Progress) {
        let done = max(0, p.completedUnitCount)
        let total = p.totalUnitCount
        let now = Date()
        let elapsed = max(0.1, now.timeIntervalSince(lastSample))
        let delta = max(0, done - lastBytes)
        currentBytesPerSecond = Double(delta) / elapsed
        lastBytes = done
        lastSample = now
        downloadedText = formatBytes(done)
        speedText = currentBytesPerSecond > 0 ? "\(formatBytes(Int64(currentBytesPerSecond)))/s" : "Calculando…"
        if total > 0 {
            let fraction = min(1, max(0, Double(done) / Double(total)))
            progress = fraction
            totalText = formatBytes(total)
            let remaining = max(0, Double(total - done) / max(currentBytesPerSecond, 1))
            etaText = currentBytesPerSecond > 0 ? formatDuration(remaining) : "Calculando…"
            status = "Descargando ZIP · \(Int(fraction * 100))%"
            upsertHistory(state: "Descargando", fraction: fraction)
        } else {
            progress = nil
            totalText = "Tamaño desconocido"
            etaText = "No disponible"
            status = "Descargando ZIP · \(formatBytes(done)) recibidos"
            upsertHistory(state: "Descargando", fraction: 0)
        }
    }

    func download(_ download: WKDownload, decideDestinationUsing response: URLResponse, suggestedFilename: String, completionHandler: @escaping (URL?) -> Void) {
        let safeName = suggestedFilename.isEmpty ? "download.zip" : suggestedFilename
        currentFilename = safeName
        let destination = FileManager.default.temporaryDirectory.appendingPathComponent("ZipPinch-\(UUID().uuidString)-\(safeName)")
        lastDestination = destination
        completionHandler(destination)
    }

    func downloadDidFinish(_ download: WKDownload) {
        timer?.invalidate(); timer = nil
        activeDownload = nil
        isDownloading = false
        isPaused = false
        progress = 1
        speedText = "—"
        etaText = "Completada"
        status = "Descarga terminada. Elegí una carpeta para extraer el ZIP."
        upsertHistory(state: "Descargada · esperando extracción", fraction: 1)
        // WebKit doesn't expose its destination here, so use the URL captured in the destination callback.
        if let url = lastDestination, FileManager.default.fileExists(atPath: url.path) {
            onZIPReady?(url)
        } else {
            status = "La descarga terminó, pero no se encontró el archivo temporal."
            upsertHistory(state: "Error: archivo no encontrado", fraction: 1)
        }
    }

    private var lastDestination: URL?

    func download(_ download: WKDownload, didFailWithError error: Error, resumeData: Data?) {
        timer?.invalidate(); timer = nil
        activeDownload = nil
        self.resumeData = resumeData
        isDownloading = false
        isPaused = resumeData != nil
        speedText = "0 MB/s"
        etaText = resumeData == nil ? "No disponible" : "Pausada por error"
        status = resumeData == nil
            ? "Falló la descarga: \(error.localizedDescription). Volvé a intentarlo desde GoFile."
            : "Se perdió la conexión o falló la descarga. Podés intentar reanudarla."
        upsertHistory(state: resumeData == nil ? "Error" : "Interrumpida · reanudable", fraction: progress ?? 0)
    }

    func destinationWasChosen(_ url: URL) { lastDestination = url }

    func startExtraction() {
        isExtracting = true
        extractionProgress = 0
        status = "Extrayendo archivos…"
    }

    func extractionUpdated(_ fraction: Double, label: String) {
        extractionProgress = fraction
        status = label
    }

    func extractionFinished(_ message: String, success: Bool) {
        isExtracting = false
        extractionProgress = success ? 1 : extractionProgress
        status = message
        upsertHistory(state: success ? "Descargada y extraída" : "Error de extracción", fraction: 1)
        if success, let lastDestination { try? FileManager.default.removeItem(at: lastDestination) }
    }

    private func upsertHistory(state: String, fraction: Double) {
        let record = DownloadRecord(id: "active", name: currentFilename, state: state, fraction: fraction, downloaded: downloadedText, total: totalText, speed: speedText, eta: etaText)
        if let index = history.firstIndex(where: { $0.id == "active" }) { history[index] = record }
        else { history.insert(record, at: 0) }
    }

    private func formatBytes(_ value: Int64) -> String {
        ByteCountFormatter.string(fromByteCount: value, countStyle: .file)
    }
    private func formatDuration(_ seconds: Double) -> String {
        guard seconds.isFinite, seconds >= 0, seconds < 60 * 60 * 24 * 365 else { return "Calculando…" }
        let s = Int(seconds.rounded())
        if s < 60 { return "\(s) s" }
        if s < 3600 { return "\(s / 60) min \(s % 60) s" }
        return "\(s / 3600) h \((s % 3600) / 60) min"
    }
}

struct DownloadRecord: Identifiable {
    let id: String
    let name: String
    let state: String
    let fraction: Double
    let downloaded: String
    let total: String
    let speed: String
    let eta: String
}

struct ContentView: View {
    @StateObject private var manager = DownloadManager()
    @State private var address = "https://gofile.io"
    @State private var browserID = UUID()
    @State private var pendingZIP: URL?
    @State private var showFolderPicker = false
    @State private var selectedTab = 0

    var body: some View {
        TabView(selection: $selectedTab) {
            NavigationView {
                VStack(spacing: 10) {
                    HStack(spacing: 8) {
                        TextField("URL de GoFile", text: $address)
                            .textInputAutocapitalization(.never).keyboardType(.URL).autocorrectionDisabled().textFieldStyle(.roundedBorder)
                        Button("Ir") { navigate() }.buttonStyle(.borderedProminent)
                    }
                    BrowserView(startURL: normalizedURL(address), manager: manager)
                        .id(browserID)
                        .clipShape(RoundedRectangle(cornerRadius: 12))
                }
                .padding(12)
                .navigationTitle("Navegador")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .navigationBarTrailing) {
                        Button("GoFile") { address = "https://gofile.io"; navigate() }
                    }
                }
            }
            .tabItem { Label("Navegar", systemImage: "safari") }
            .tag(0)

            NavigationView {
                ScrollView {
                    VStack(alignment: .leading, spacing: 16) {
                        HStack {
                            VStack(alignment: .leading, spacing: 4) {
                                Text(manager.currentFilename).font(.headline).lineLimit(2)
                                Text(manager.status).font(.subheadline).foregroundColor(.secondary)
                            }
                            Spacer()
                            if manager.isDownloading {
                                Button { manager.pause() } label: { Label("Pausar", systemImage: "pause.fill") }.buttonStyle(.borderedProminent)
                            } else if manager.isPaused {
                                Button { manager.resume() } label: { Label("Reanudar", systemImage: "play.fill") }.buttonStyle(.borderedProminent)
                            }
                        }
                        if manager.isDownloading || manager.isPaused || manager.isExtracting || manager.progress != nil {
                            if manager.isExtracting {
                                ProgressView(value: manager.extractionProgress)
                                Text("Extracción: \(Int(manager.extractionProgress * 100))%")
                                    .font(.caption.monospacedDigit())
                            } else if let progress = manager.progress {
                                ProgressView(value: progress)
                                Text("Descarga: \(Int(progress * 100))%")
                                    .font(.caption.monospacedDigit())
                            } else {
                                ProgressView()
                                Text("Porcentaje no disponible: el servidor no informa el tamaño total.").font(.caption).foregroundColor(.secondary)
                            }
                            LazyVGrid(columns: [GridItem(.flexible()), GridItem(.flexible())], spacing: 10) {
                                infoCard("Recibido", manager.downloadedText, icon: "arrow.down.circle")
                                infoCard("Tamaño total", manager.totalText, icon: "doc.zipper")
                                infoCard("Velocidad", manager.speedText, icon: "speedometer")
                                infoCard("Tiempo restante", manager.etaText, icon: "clock")
                            }
                        } else {
                            VStack(spacing: 10) { Image(systemName: "arrow.down.to.line").font(.largeTitle).foregroundColor(.secondary); Text("Sin descargas").font(.headline); Text("Las descargas iniciadas desde GoFile aparecerán acá.").font(.subheadline).foregroundColor(.secondary).multilineTextAlignment(.center) }.frame(maxWidth: .infinity).padding(.vertical, 30)
                        }
                        Divider()
                        Text("Actividad reciente").font(.headline)
                        ForEach(manager.history) { item in
                            VStack(alignment: .leading, spacing: 5) {
                                Text(item.name).font(.subheadline.weight(.semibold))
                                Text(item.state).font(.caption).foregroundColor(.secondary)
                                if item.state.contains("Descargando") {
                                    ProgressView(value: item.fraction)
                                }
                            }
                            .padding(12)
                            .frame(maxWidth: .infinity, alignment: .leading)
                            .background(Color.secondary.opacity(0.08))
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                        }
                    }
                    .padding()
                }
                .navigationTitle("Descargas")
                .navigationBarTitleDisplayMode(.inline)
            }
            .tabItem { Label("Descargas", systemImage: "arrow.down.circle") }
            .tag(1)
        }
        .onAppear {
            manager.onZIPReady = { zip in pendingZIP = zip; showFolderPicker = true; selectedTab = 1 }
        }
        .fileImporter(isPresented: $showFolderPicker, allowedContentTypes: [.folder], allowsMultipleSelection: false) { result in
            switch result {
            case .success(let urls):
                guard let folder = urls.first, let zip = pendingZIP else { manager.status = "No se eligió carpeta."; return }
                extract(zip, into: folder)
            case .failure(let error):
                manager.status = "No se eligió carpeta: \(error.localizedDescription)"
            }
        }
    }

    private func infoCard(_ title: String, _ value: String, icon: String) -> some View {
        VStack(alignment: .leading, spacing: 8) {
            Label(title, systemImage: icon).font(.caption).foregroundColor(.secondary)
            Text(value).font(.headline.monospacedDigit()).lineLimit(2).minimumScaleFactor(0.75)
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color.secondary.opacity(0.08))
        .clipShape(RoundedRectangle(cornerRadius: 12))
    }

    private func navigate() {
        guard normalizedURL(address) != nil else { manager.status = "La dirección no es válida. Incluí https://"; return }
        browserID = UUID(); manager.status = "Abriendo página…"
    }
    private func normalizedURL(_ value: String) -> URL? {
        let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !trimmed.isEmpty else { return nil }
        return URL(string: trimmed.contains("://") ? trimmed : "https://" + trimmed)
    }
    private func extract(_ zipURL: URL, into selectedFolder: URL) {
        manager.startExtraction()
        DispatchQueue.global(qos: .userInitiated).async {
            let hasAccess = selectedFolder.startAccessingSecurityScopedResource()
            defer { if hasAccess { selectedFolder.stopAccessingSecurityScopedResource() } }
            do {
                let fm = FileManager.default
                let outputName = "ZipPinch-Extraído-\(Date.now.formatted(.dateTime.year().month().day().hour().minute()))"
                let root = selectedFolder.appendingPathComponent(outputName, isDirectory: true)
                try fm.createDirectory(at: root, withIntermediateDirectories: true)
                let archive = try Archive(url: zipURL, accessMode: .read)
                let entries = Array(archive); let total = max(entries.count, 1)
                for (index, entry) in entries.enumerated() {
                    let safeParts = entry.path.split(separator: "/").filter { $0 != ".." && $0 != "." }
                    guard !safeParts.isEmpty else { continue }
                    let destination = safeParts.reduce(root) { $0.appendingPathComponent(String($1)) }
                    if entry.type == .directory {
                        try fm.createDirectory(at: destination, withIntermediateDirectories: true)
                    } else {
                        try fm.createDirectory(at: destination.deletingLastPathComponent(), withIntermediateDirectories: true)
                        try archive.extract(entry, to: destination)
                    }
                    let fraction = Double(index + 1) / Double(total)
                    DispatchQueue.main.async { manager.extractionUpdated(fraction, label: "Extrayendo: \(Int(fraction * 100))% · \(index + 1)/\(total) archivos") }
                }
                DispatchQueue.main.async {
                    manager.extractionFinished("Listo. Archivos guardados en \(outputName).", success: true)
                    pendingZIP = nil
                }
            } catch {
                DispatchQueue.main.async { manager.extractionFinished("No se pudo extraer el ZIP: \(error.localizedDescription)", success: false) }
            }
        }
    }
}

private struct BrowserView: UIViewRepresentable {
    let startURL: URL?
    @ObservedObject var manager: DownloadManager
    func makeCoordinator() -> Coordinator { Coordinator(manager: manager) }
    func makeUIView(context: Context) -> WKWebView {
        let config = WKWebViewConfiguration(); config.defaultWebpagePreferences.allowsContentJavaScript = true
        let web = WKWebView(frame: .zero, configuration: config)
        web.navigationDelegate = context.coordinator; web.uiDelegate = context.coordinator
        web.allowsBackForwardNavigationGestures = true
        manager.attach(webView: web)
        if let startURL { web.load(URLRequest(url: startURL)) }
        return web
    }
    func updateUIView(_ webView: WKWebView, context: Context) {}

    final class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        let manager: DownloadManager
        init(manager: DownloadManager) { self.manager = manager }
        func webView(_ webView: WKWebView, didStartProvisionalNavigation navigation: WKNavigation!) { Task { @MainActor in manager.status = "Cargando página…" } }
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) { Task { @MainActor in if !manager.isDownloading && !manager.isPaused { manager.status = "Página lista. Tocá Descargar en GoFile." } } }
        func webView(_ webView: WKWebView, didFail navigation: WKNavigation!, withError error: Error) { Task { @MainActor in manager.status = "Error al abrir la página: \(error.localizedDescription)" } }
        func webView(_ webView: WKWebView, navigationResponse: WKNavigationResponse, didBecome download: WKDownload) { Task { @MainActor in manager.begin(download, webView: webView) } }
        func webView(_ webView: WKWebView, decidePolicyFor navigationResponse: WKNavigationResponse, decisionHandler: @escaping (WKNavigationResponsePolicy) -> Void) {
            let response = navigationResponse.response
            let mime = (response.mimeType ?? "").lowercased()
            let name = (response.suggestedFilename ?? "download").lowercased()
            let disposition = ((response as? HTTPURLResponse)?.value(forHTTPHeaderField: "Content-Disposition") ?? "").lowercased()
            let looksLikeArchive = name.hasSuffix(".zip") || mime.contains("zip") || mime.contains("x-zip") || disposition.contains("attachment")
            decisionHandler((navigationResponse.canShowMIMEType == false || looksLikeArchive) ? .download : .allow)
        }
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if navigationAction.targetFrame == nil, let url = navigationAction.request.url { webView.load(URLRequest(url: url)) }
            return nil
        }
    }
}
