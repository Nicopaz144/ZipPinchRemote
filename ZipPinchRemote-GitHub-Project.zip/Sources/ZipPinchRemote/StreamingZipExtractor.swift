import Foundation
#if canImport(FoundationNetworking)
import FoundationNetworking
#endif

/// Sequential ZIP reader. It never writes the archive itself to disk: network bytes are
/// parsed as they arrive and each entry is written directly to the destination folder.
/// Supported: ZIP local headers with known sizes, methods 0 (stored) and 8 (raw DEFLATE).
/// Safely rejects data-descriptor/ZIP64/encrypted entries rather than silently corrupting output.
final class StreamingZipExtractor: NSObject, URLSessionDataDelegate {
    enum StreamError: LocalizedError {
        case badResponse(Int), unsupported(String), malformed(String), unsafePath, incomplete
        var errorDescription: String? {
            switch self {
            case .badResponse(let code): return "El servidor respondió HTTP \(code)."
            case .unsupported(let text): return "ZIP no compatible con extracción secuencial: \(text)."
            case .malformed(let text): return "ZIP inválido: \(text)."
            case .unsafePath: return "El ZIP contiene una ruta insegura; se canceló para proteger tus archivos."
            case .incomplete: return "La conexión terminó antes de completar el ZIP."
            }
        }
    }

    private let destination: URL
    private let completion: (Result<Int, Error>) -> Void
    private let progress: (Int64, String) -> Void
    private var session: URLSession!
    private var buffer = Data()
    private var expectedCompressed: UInt64 = 0
    private var currentMethod: UInt16 = 0
    private var currentName = ""
    private var currentOutput: FileHandle?
    private var currentOutputURL: URL?
    private var inflater = z_stream()
    private var inflaterReady = false
    private var totalBytes: Int64 = 0
    private var filesDone = 0
    private var finished = false
    private var entryIsDirectory = false

    init(destination: URL, progress: @escaping (Int64, String) -> Void,
         completion: @escaping (Result<Int, Error>) -> Void) {
        self.destination = destination
        self.progress = progress
        self.completion = completion
        super.init()
    }

    func start(_ url: URL) {
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        request.timeoutInterval = 120
        let config = URLSessionConfiguration.default
        config.timeoutIntervalForRequest = 120
        session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
        session.dataTask(with: request).resume()
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask,
                    didReceive response: URLResponse,
                    completionHandler: @escaping (URLSession.ResponseDisposition) -> Void) {
        guard let http = response as? HTTPURLResponse, (200...299).contains(http.statusCode) else {
            let code = (response as? HTTPURLResponse)?.statusCode ?? -1
            finish(.failure(StreamError.badResponse(code))); completionHandler(.cancel); return
        }
        completionHandler(.allow)
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        guard !finished else { return }
        // Some file hosts return an HTML error/landing page with HTTP 200. Detect it
        // before the ZIP parser mistakes its bytes for a corrupt local-header signature.
        if buffer.isEmpty, currentOutput == nil, filesDone == 0, expectedCompressed == 0,
           looksLikeHTML(data) {
            finish(.failure(StreamError.malformed("el servidor devolvió HTML en vez del ZIP. El enlace puede haber expirado, requerir una página intermedia o estar bloqueado por el host. Verificá que sea un enlace de descarga directa.")))
            return
        }
        buffer.append(data)
        do { try consumeAvailable() } catch { finish(.failure(error)) }
    }

    private func looksLikeHTML(_ data: Data) -> Bool {
        let prefix = data.prefix(512)
        guard let text = String(data: prefix, encoding: .utf8) else { return false }
        let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
        return trimmed.hasPrefix("<!doctype html") || trimmed.hasPrefix("<html") ||
               trimmed.hasPrefix("<!do") || trimmed.hasPrefix("<head") ||
               trimmed.hasPrefix("<body")
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        if finished { return }
        if let error { finish(.failure(error)); return }
        do {
            try consumeAvailable()
            guard buffer.isEmpty, currentOutput == nil else { throw StreamError.incomplete }
            finish(.success(filesDone))
        } catch { finish(.failure(error)) }
    }

    private func consumeAvailable() throws {
        while !finished {
            if currentOutput != nil || entryIsDirectory {
                if expectedCompressed == 0 {
                    try closeCurrentEntry()
                    continue
                }
                guard !buffer.isEmpty else { return }
                let count = min(buffer.count, Int(min(expectedCompressed, UInt64(Int.max))))
                let chunk = buffer.prefix(count)
                buffer.removeFirst(count)
                expectedCompressed -= UInt64(count)
                if currentMethod == 0 {
                    if !entryIsDirectory { try currentOutput?.write(contentsOf: chunk) }
                    totalBytes += Int64(count)
                } else if currentMethod == 8 {
                    try inflateChunk(Data(chunk), isFinal: expectedCompressed == 0)
                }
                if expectedCompressed == 0 { try closeCurrentEntry() }
                progress(totalBytes, currentName)
                continue
            }
            guard buffer.count >= 4 else { return }
            let signature = buffer.uint32LE(at: 0)
            if signature == 0x02014b50 || signature == 0x06054b50 || signature == 0x06064b50 {
                // Central directory / end-of-central-directory: local entries are complete.
                buffer.removeAll(keepingCapacity: false)
                return
            }
            guard signature == 0x04034b50 else {
                throw StreamError.malformed("firma local desconocida (0x\(String(signature, radix: 16)))")
            }
            guard buffer.count >= 30 else { return }
            let flags = buffer.uint16LE(at: 6)
            let method = buffer.uint16LE(at: 8)
            let compressed = buffer.uint32LE(at: 18)
            let uncompressed = buffer.uint32LE(at: 22)
            let nameLength = Int(buffer.uint16LE(at: 26))
            let extraLength = Int(buffer.uint16LE(at: 28))
            let headerLength = 30 + nameLength + extraLength
            guard buffer.count >= headerLength else { return }
            guard flags & 0x0001 == 0 else { throw StreamError.unsupported("entrada cifrada") }
            guard flags & 0x0008 == 0 else { throw StreamError.unsupported("usa descriptor de datos; este modo seguro todavía no lo admite") }
            guard compressed != UInt32.max, uncompressed != UInt32.max else { throw StreamError.unsupported("ZIP64") }
            guard method == 0 || method == 8 else { throw StreamError.unsupported("método de compresión \(method)") }
            let nameData = buffer.subdata(in: 30..<(30 + nameLength))
            let rawName = String(data: nameData, encoding: .utf8) ?? String(decoding: nameData, as: UTF8.self)
            buffer.removeFirst(headerLength)
            let safe = try safeDestination(for: rawName)
            currentName = rawName
            currentMethod = method
            expectedCompressed = UInt64(compressed)
            entryIsDirectory = rawName.hasSuffix("/") || rawName.hasSuffix("\\")
            if entryIsDirectory {
                try FileManager.default.createDirectory(at: safe, withIntermediateDirectories: true)
                currentOutputURL = nil
                currentOutput = nil
            } else {
                try FileManager.default.createDirectory(at: safe.deletingLastPathComponent(), withIntermediateDirectories: true)
                FileManager.default.createFile(atPath: safe.path, contents: nil)
                currentOutputURL = safe
                currentOutput = try FileHandle(forWritingTo: safe)
                if method == 8 { try startInflater() }
            }
            if expectedCompressed == 0 { try closeCurrentEntry() }
        }
    }

    private func safeDestination(for path: String) throws -> URL {
        let normalized = path.replacingOccurrences(of: "\\", with: "/")
        guard !normalized.hasPrefix("/"), !normalized.contains(":") else { throw StreamError.unsafePath }
        let components = normalized.split(separator: "/", omittingEmptySubsequences: true)
        guard !components.isEmpty, !components.contains(".."), !components.contains(".") else { throw StreamError.unsafePath }
        return components.reduce(destination) { $0.appendingPathComponent(String($1)) }
    }

    private func startInflater() throws {
        inflater = z_stream()
        let result = inflateInit2_(&inflater, -MAX_WBITS, ZLIB_VERSION, Int32(MemoryLayout<z_stream>.size))
        guard result == Z_OK else { throw StreamError.malformed("no se pudo iniciar DEFLATE") }
        inflaterReady = true
    }

    private func inflateChunk(_ data: Data, isFinal: Bool) throws {
        guard inflaterReady else { throw StreamError.malformed("DEFLATE no inicializado") }
        try data.withUnsafeBytes { raw in
            guard let base = raw.bindMemory(to: Bytef.self).baseAddress else { return }
            inflater.next_in = UnsafeMutablePointer(mutating: base)
            inflater.avail_in = uInt(data.count)
            var output = [UInt8](repeating: 0, count: 64 * 1024)
            repeat {
                let produced: Int = output.withUnsafeMutableBufferPointer { out in
                    inflater.next_out = out.baseAddress
                    inflater.avail_out = uInt(out.count)
                    _ = inflate(&inflater, Z_NO_FLUSH)
                    return out.count - Int(inflater.avail_out)
                }
                if produced > 0 {
                    try currentOutput?.write(contentsOf: Data(output[0..<produced]))
                    totalBytes += Int64(produced)
                }
                if inflater.avail_in == 0 && inflater.avail_out > 0 { break }
            } while true
        }
        if isFinal {
            // A final call must reach stream end; some archives may need a zero-input flush.
            var output = [UInt8](repeating: 0, count: 64 * 1024)
            var ended = false
            repeat {
                let code: Int32 = output.withUnsafeMutableBufferPointer { out in
                    inflater.next_in = nil; inflater.avail_in = 0
                    inflater.next_out = out.baseAddress; inflater.avail_out = uInt(out.count)
                    let status = inflate(&inflater, Z_FINISH)
                    let produced = out.count - Int(inflater.avail_out)
                    if produced > 0 {
                        try? currentOutput?.write(contentsOf: Data(out.prefix(produced)))
                        totalBytes += Int64(produced)
                    }
                    return status
                }
                if code == Z_STREAM_END { ended = true; break }
                if code != Z_OK && code != Z_BUF_ERROR { break }
                if code == Z_BUF_ERROR { break }
            } while true
            inflateEnd(&inflater); inflaterReady = false
            guard ended else { throw StreamError.malformed("bloque DEFLATE incompleto o inválido en \(currentName)") }
        }
    }

    private func closeCurrentEntry() throws {
        if inflaterReady { inflateEnd(&inflater); inflaterReady = false }
        try currentOutput?.close()
        if currentOutput != nil { filesDone += 1 }
        currentOutput = nil
        currentOutputURL = nil
        currentName = ""
        currentMethod = 0
        entryIsDirectory = false
        expectedCompressed = 0
    }

    private func finish(_ result: Result<Int, Error>) {
        guard !finished else { return }
        finished = true
        if inflaterReady { inflateEnd(&inflater); inflaterReady = false }
        try? currentOutput?.close()
        session?.invalidateAndCancel()
        completion(result)
    }
}

private extension Data {
    func uint16LE(at offset: Int) -> UInt16 {
        UInt16(self[offset]) | (UInt16(self[offset + 1]) << 8)
    }
    func uint32LE(at offset: Int) -> UInt32 {
        UInt32(self[offset]) | (UInt32(self[offset + 1]) << 8) | (UInt32(self[offset + 2]) << 16) | (UInt32(self[offset + 3]) << 24)
    }
}
